package com.almacenamiento.demo.controller;



import java.awt.print.Printable;
import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;



@Controller
public class LoginController {
	
	@GetMapping("/login")
	public String login(@RequestParam(value="error", required=false) String error, Model model,Principal principal, RedirectAttributes flash){
		
		if(principal!=null) {
			flash.addFlashAttribute("info","Ya ha iniciado sesión anteriormente");
			
			return "redirect:/home";
		}
		
		if(error!=null) {
			System.out.println("Existieron errores en el formulariasdasdasdo");
			model.addAttribute("error","error en el login de usuario o contraseña incorrecta, por favor vuelve a intentarlo!");
		}
		return "logueo";
	}
}
