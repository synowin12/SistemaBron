package com.almacenamiento.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlmacenamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
